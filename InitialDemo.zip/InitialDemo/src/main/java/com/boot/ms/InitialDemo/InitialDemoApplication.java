package com.boot.ms.InitialDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InitialDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(InitialDemoApplication.class, args);
	}

}
