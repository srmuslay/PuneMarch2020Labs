package com.boot.ms.InitialDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InitialDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
